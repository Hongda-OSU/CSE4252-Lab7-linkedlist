/*Name Hongda Lin (lin.3235)*/
/*Date: 23/3/2021*/
#include <iostream>
#include <ios>
#include <limits>
#include <cctype>
#include <stdlib.h>
#include <cstring>
#include <iomanip>
#include <fstream>
#include "utility.h"
using namespace std;

int main(){
    char name[50], instr[50];
    bool continueProgram = true;
    char fileName[] = "Data.7";
    int numNode = 0, input = 0;
    unsigned int ID;
    /* create the head node and the reference to it */
    Node *ptr_head = NULL;
    Node **ptr2_head = &ptr_head;
    ifstream in_stream;
    /* read the file */
    in_stream.open(fileName);
    if(in_stream.fail()){
        cout<<"Input file opening failed."<<endl;
        exit(EXIT_FAILURE);
    }
    cout<<"Creating a link list using data from "<<fileName<<" file"<<endl;
    /* set up the linked list */
    while(in_stream>>name){
	 char firstName[20], lastName[30];
         setName(name, lastName, firstName);
         in_stream>>ID;
         if(validId(ptr_head, ID)){
            push(ptr2_head, lastName, firstName, ID);
         }else{
            displayErrorInput(input, firstName, lastName, ID);
         }
         input++;
    }
    /* reverse the current linked list(reverse order) */
    reverse(ptr2_head); 
    /* sort the node in reversed linked list by the value of id */
    insertionSort(ptr2_head);
    /* count the nodes */ 
    numNode = countNode(ptr_head);

    cout<<endl<<"Link list created. Number of nodes = "<<numNode<<endl;
    while(continueProgram){
          displayTable();
          cin>>instr;
          cin.clear();
          cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
          if(instrCheck(instr)){
             cout<<"You entered= "<<instr<<endl;          
          }
          /* print the list */
          if(strcmp(instr, "p") == 0){
             displayList(ptr_head);
          }
          /* exit the list */
          if(strcmp(instr, "e") == 0){
	     deleteList(ptr2_head);
             cout<<"Goodbye."<<endl;
             continueProgram = false;    
          }
          /* delete the list */
 	  if(strcmp(instr, "d") == 0){
             deleteList(ptr2_head);
             numNode = countNode(ptr_head);
	     cout<<"List has been destroyed; Number of nodes= "<<numNode<<endl;
          }
          /* add a node to the list */
          if(strcmp(instr, "a") == 0){
             insertNode(ptr2_head);
             numNode = countNode(ptr_head);
	     cout<<"Node added to the list; Number of nodes= "<<numNode<<endl;
          }
          /* remove a node from the list */
	  if(strcmp(instr, "r") == 0){
             removeNode(ptr2_head);
             numNode = countNode(ptr_head);
	     cout<<"Node removed from the list; Number of nodes= "<<numNode<<endl;
          }
    } 
    /* close file */
    in_stream.close();
    return 0;
}
