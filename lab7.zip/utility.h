/*Name Hongda Lin (lin.3235)*/
/*Date: 23/3/2021*/
#include <iostream>
#include <ios>
#include <limits>
#include <cctype>
#include <stdlib.h>
#include <cstring>
#include <iomanip>
#include <fstream>

using namespace std;

#define stewSize1 5
#define stewSize2 20

class Node{  
     public:
       /* default constructor */
       Node();
       /* non-default constructor */
       Node(Node *next, char *lastName, char *firstName, unsigned int ID);
     
       /* getter functions */
       void getLastName()const;
       void getFirstName()const;
       unsigned int getId()const;
       Node *getLink()const;

       /* setter functions */
       void setId(unsigned int ID);
       void setLastName(char *lastName);
       void setFirstName(char *firstName);
       void setLink(Node *next);

     /* private data section */
     private:
       char last[30];
       char first[20];
       unsigned int id;
       Node *link;
}; 

/* function prototypes */
void push(Node **ptr2_head, char *lastName, char *firstName, unsigned int ID);
int countNode(Node *ptr_head);
void setName(char *name, char *lastName, char *firstName);
int validId(Node *ptr_head, unsigned int ID);
int validIndex(Node *ptr_head, int index);
void displayErrorInput(int input, char *firstName, char *lastName, unsigned int ID);
void displayTable();
bool instrCheck(char instr[50]);
void displayList(Node *ptr_head);
void reverse(Node **ptr2_head);
void sortedInsert(Node **ptr2_head, Node *new_node);
void insertionSort(Node **ptr2_head);
void deleteList(Node **ptr2_head);
void insertNode(Node **ptr2_head);
void removeByIndex(Node **ptr2_head, int index);
void removeNode(Node **ptr2_head);
